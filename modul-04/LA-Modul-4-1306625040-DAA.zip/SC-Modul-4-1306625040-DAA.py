
import openpyxl
 
# IDENTITAS 
NAMA = "Debby Ariesti Arifin"
NRM = "1306625040"
 
FILE_EXCEL = "DataNilai.xlsx"
 
 
# Fungsi untuk menentukan grade 
def tentukan_grade(na):
    if na >= 86:
        grade = "A"
    elif na >= 81:
        grade = "A-"
    elif na >= 76:
        grade = "B+"
    elif na >= 71:
        grade = "B"
    elif na >= 66:
        grade = "B-"
    elif na >= 61:
        grade = "C+"
    elif na >= 56:
        grade = "C"
    else:
        grade = "TL"
    return grade
 
 
# 1. Membaca data dari Excel 
workbook = openpyxl.load_workbook(FILE_EXCEL, data_only=True)
sheet = workbook.active
 
# Simpan setiap kolom ke dalam list
daftar_nama = []
daftar_lain = []
daftar_uts = []
daftar_uas = []
 
# Baris 1 adalah judul kolom, jadi data dimulai dari baris 2
for baris in sheet.iter_rows(min_row=2, values_only=True):
    if baris[0] is None:          # lewati baris kosong
        continue
    daftar_nama.append(baris[0])  # kolom A : Mahasiswa
    daftar_lain.append(baris[2])  # kolom C : Nilai Lain2
    daftar_uts.append(baris[3])   # kolom D : Nilai UTS
    daftar_uas.append(baris[4])   # kolom E : Nilai UAS
 
total_mahasiswa = len(daftar_nama)
 
# 2. Header laporan
print("Program Grading")
print("Nama :", NAMA)
print("NRM  :", NRM)
print()
print("LAPORAN GRADING MAHASISWA")
print("-----------------------------------------")
print(" No |     Nama      |  Nilai  |  Grade  |")
print("    |   Mahasiswa   |  Akhir  |         |")
print("----|---------------|---------|---------|")
 
# 3. Hitung nilai akhir, grade, dan counting 
jumlah_A = 0
jumlah_A_min = 0
jumlah_B_plus = 0
jumlah_B = 0
jumlah_B_min = 0
jumlah_C_plus = 0
jumlah_C = 0
jumlah_TL = 0
 
i = 0
while i < total_mahasiswa:
    nilai_akhir = 0.30 * daftar_lain[i] + 0.35 * daftar_uts[i] + 0.35 * daftar_uas[i]
    grade = tentukan_grade(nilai_akhir)
 
    # cetak satu baris tabel
    print(f"{i + 1:^4}| {daftar_nama[i]:<13} | {nilai_akhir:<7.2f} | {grade:<7} |")
 
    # counting
    if grade == "A":
        jumlah_A += 1
    elif grade == "A-":
        jumlah_A_min += 1
    elif grade == "B+":
        jumlah_B_plus += 1
    elif grade == "B":
        jumlah_B += 1
    elif grade == "B-":
        jumlah_B_min += 1
    elif grade == "C+":
        jumlah_C_plus += 1
    elif grade == "C":
        jumlah_C += 1
    else:
        jumlah_TL += 1
 
    i += 1
 
print("-----------------------------------------")
 
# 4. Rekapitulasi
print("Rekapitulasi :")
print("Grade A      =", jumlah_A)
print("Grade A-     =", jumlah_A_min)
print("Grade B+     =", jumlah_B_plus)
print("Grade B      =", jumlah_B)
print("Grade B-     =", jumlah_B_min)
print("Grade C+     =", jumlah_C_plus)
print("Grade C      =", jumlah_C)
print("Tidak Lulus  =", jumlah_TL)
print("Total Mahasiswa =", total_mahasiswa)
print()
print("selesai")
 