# Program Konversi Suhu

# Header dan Input Identitas
print("Program Konversi Suhu")
print("Nama: Debby Ariesti Arifin")
print("NIM: 1306625040")
print()

# Input Parameter Suhu
suhu_awal = float(input("Suhu Awal = "))
suhu_akhir = float(input("Suhu Akhir = "))
selang = float(input("Selang = "))
print ()

# Header Tabel
print("""
--------------------------------------
|           TABEL KONVERSI           |
--------------------------------------
| No | Celcius | Reamur | Fahrenheit |
--------------------------------------""")

# Inisialisasi Variabel Perulangan
Celcius = suhu_awal
no = 1

#Perulangan While untuk Perhitungan & Cetak Format Tabel
while Celcius <= suhu_akhir:
    Reamur = (4/5) * Celcius
    Fahrenheit = (9/5) * Celcius + 32

    #Cetak Baris Tabel Dengan Format Rapi
    print(f"| {no:^2g} | {Celcius:^7g} | {Reamur:^6g} | {Fahrenheit:^10g} |")
    
    no += 1
    Celcius = Celcius + selang