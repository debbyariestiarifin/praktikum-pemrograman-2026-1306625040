# DATA
nilai = [85, 13, 99, 34, 71, 15, 82, 24, 64, 61, 
         67, 99, 50, 68, 25, 37, 32, 27, 14, 91,
         79, 15, 47, 48, 74, 88, 64, 53, 77, 50, 
         24, 91, 87, 55, 60, 75, 91, 22, 47, 63,
         81, 88, 26, 48, 69, 59, 84, 77, 28, 36, 
         59, 74, 89, 73, 91, 64, 55, 88, 90, 48,
         73, 97, 98, 40, 93, 50, 78, 60, 44, 77, 
         82, 51, 53, 65, 98, 59, 94, 91, 52, 44,
         65, 85, 72, 92, 49, 67, 58, 48, 62, 54, 
         89, 67, 58, 48, 85, 45, 77, 76, 81, 77]

# HEADER
print("Program Sorting")
print("Nama : " "Debby Ariesti Arifin")  
print("NRM  : " "1306625040")
print()

# TAMPILKAN DATA AWAL
print("Data nilai awal :")
print(*nilai, sep=", ")
print()

# PROSES SORTING (BUBBLE SORT)
terurut = nilai.copy()                  
n = len(terurut)

i = 0
while i < n - 1:
    j = 0
    while j < n - 1 - i:
        if terurut[j] > terurut[j + 1]: # kalau kiri lebih besar dari kanan, tukar
            temp = terurut[j]
            terurut[j] = terurut[j + 1]
            terurut[j + 1] = temp
        j = j + 1
    i = i + 1

# TAMPILKAN DATA TERURUT (10 ANGKA PER BARIS)
print("Data nilai terurut :")
i = 0
while i < n:
    if i == n - 1:
        print(terurut[i])              
    elif (i + 1) % 10 == 0:
        print(terurut[i], end=",\n")    
    else:
        print(terurut[i], end=", ")     
    i = i + 1

print()
print ("selesai")
