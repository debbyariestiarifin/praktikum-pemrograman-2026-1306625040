import math


# 1. Fungsi faktorial
def faktorial(n):
    hasil = 1
    i = 2
    while i <= n:
        hasil = hasil * i
        i = i + 1
    return hasil


# 2. Fungsi sin deret Mc Laurin: x - x^3/3! + x^5/5! - ...
def deret_sin(x, suku):
    total = 0
    k = 0
    while k < suku:
        f = faktorial(2 * k + 1)
        total = total + ((-1) ** k) * (x ** (2 * k + 1)) / f
        k = k + 1
    return total


# 3. Fungsi cos deret Mc Laurin: 1 - x^2/2! + x^4/4! - ...
def deret_cos(x, suku):
    total = 0
    k = 0
    while k < suku:
        f = faktorial(2 * k)
        total = total + ((-1) ** k) * (x ** (2 * k)) / f
        k = k + 1
    return total


# 4. Fungsi relative error (dalam persen)
def relatif_error(av, tv):
    er = abs((av - tv) / tv) * 100
    return er


# PROGRAM UTAMA 
print("Program Sinus-Cosinus")
print("Nama : Debby Ariesti Arifin")
print("NRM  : 1306625040")

next = True
while next == True:
    print()
    derajat = float(input("Besar sudut (derajat) = "))
    x = math.radians(derajat)  # deret Mc Laurin butuh radian

    tv_sin = math.sin(x)
    tv_cos = math.cos(x)
    print()
    print(f"True value sin({derajat:g}) = {tv_sin:.6f}")
    print(f"True value cos({derajat:g}) = {tv_cos:.6f}")

    print("-" * 64)
    print(f"|{'Jumlah':^8}|{'AV':^13}|{'ER':^12}|{'AV':^13}|{'ER':^12}|")
    print(f"|{'Suku':^8}|{'sinus':^13}|{'sinus':^12}|{'cosinus':^13}|{'cos':^12}|")
    print("|" + "-" * 8 + "|" + "-" * 13 + "|" + "-" * 12 + "|" + "-" * 13 + "|" + "-" * 12 + "|")

    suku = 0
    er_sin = 100
    er_cos = 100
    while er_sin > 5 or er_cos > 5:
        suku = suku + 1
        av_sin = deret_sin(x, suku)
        av_cos = deret_cos(x, suku)
        er_sin = relatif_error(av_sin, tv_sin)
        er_cos = relatif_error(av_cos, tv_cos)
        teks_sin = f"{er_sin:.4f}%"
        teks_cos = f"{er_cos:.4f}%"
        print(f"|{suku:^8}|{av_sin:^13.6f}|{teks_sin:^12}|{av_cos:^13.6f}|{teks_cos:^12}|")

    print("-" * 64)
    print()
    lagi = input("\nMau menghitung lagi? (y/t): ").strip().lower()
    if lagi != "y":
        next = False
