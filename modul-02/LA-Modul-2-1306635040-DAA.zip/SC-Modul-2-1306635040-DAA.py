#Identitas
print("Program Faktor Bilangan")
print("Nama : Debby Ariesti Arifin")
print("NIM  : 1306635040")
print()

#Input Bilangan
while True:
    bilangan = int(input("Masukkan sembarang bilangan < 100 (masukkan 0 untuk selesai): "))

#Perulangan While True
    while bilangan < 0 or bilangan > 100:
        print("Bilangan harus berada dalam rentang 0 hingga 100.")
        bilangan = int(input("Masukkan sembarang bilangan < 100 (masukkan 0 untuk selesai): "))
    if bilangan == 0:
        print("Program selesai.")
        break

#Perhitungan Faktor Bilangan
    else:
        angka_faktor = 1
        faktor_list = []
        while angka_faktor <= bilangan:
            if bilangan % angka_faktor == 0:
                faktor_list.append(angka_faktor)
            angka_faktor = angka_faktor + 1

        print("Bilangan", bilangan, "-> Faktornya =", faktor_list)
        print()





